package com.lanternworks;

import net.minecraft.client.renderer.entity.EntityRendererManager;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.model.IronGolemModel;
import net.minecraft.util.ResourceLocation;

public class MechRenderer extends MobRenderer<MechSuitEntity, IronGolemModel<MechSuitEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(LanternWorks.MOD_ID, "textures/entity/mech_suit.png");

    public MechRenderer(EntityRendererManager manager) {
        super(manager, new IronGolemModel<>(), 0.9F);
    }

    @Override
    public ResourceLocation getTextureLocation(MechSuitEntity entity) {
        return TEXTURE;
    }
}
