package com.lanternworks;

import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUseContext;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

public class ShackConstructItem extends Item {
    public static final int COST = 150;

    public ShackConstructItem(Item.Properties props) {
        super(props);
    }

    @Override
    public ActionResultType useOn(ItemUseContext ctx) {
        World world = ctx.getLevel();
        PlayerEntity player = ctx.getPlayer();
        if (world.isClientSide || player == null) {
            return ActionResultType.sidedSuccess(world.isClientSide);
        }
        if (player.getCooldowns().isOnCooldown(this)) {
            return ActionResultType.FAIL;
        }
        if (!RingUtil.spend(player, COST)) {
            player.displayClientMessage(new StringTextComponent("The shack needs a Power Ring with enough charge."), true);
            return ActionResultType.FAIL;
        }

        Direction forward = ctx.getHorizontalDirection();
        Direction right = forward.getClockWise();
        BlockPos origin = ctx.getClickedPos().relative(ctx.getClickedFace());
        BlockPos center = origin.relative(forward, 3);
        BlockState wall = ModBlocks.SHACK_CONSTRUCT.get().defaultBlockState();

        // 5x5 footprint, 3 high interior, roof on top, doorway facing the player.
        for (int lx = -2; lx <= 2; lx++) {
            for (int lz = -2; lz <= 2; lz++) {
                boolean edge = Math.abs(lx) == 2 || Math.abs(lz) == 2;
                for (int dy = 0; dy <= 3; dy++) {
                    boolean roof = dy == 3;
                    if (!roof && !edge) continue;
                    boolean door = lz == -2 && lx == 0 && dy <= 1;
                    if (door) continue;
                    BlockPos pos = center.relative(right, lx).relative(forward, lz).above(dy);
                    if (world.getBlockState(pos).getMaterial().isReplaceable()) {
                        world.setBlock(pos, wall, 3);
                    }
                }
            }
        }

        ServerWorld sw = (ServerWorld) world;
        sw.sendParticles(ParticleTypes.HAPPY_VILLAGER, center.getX() + 0.5D, center.getY() + 1.5D,
                center.getZ() + 0.5D, 30, 1.5D, 1.0D, 1.5D, 0.05D);
        world.playSound(null, center, SoundEvents.BEACON_POWER_SELECT, SoundCategory.PLAYERS, 0.8F, 1.4F);

        player.getCooldowns().addCooldown(this, 40);
        return ActionResultType.CONSUME;
    }
}
