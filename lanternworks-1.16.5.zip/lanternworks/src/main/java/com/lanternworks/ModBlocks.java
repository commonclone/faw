package com.lanternworks;

import net.minecraft.block.Block;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, LanternWorks.MOD_ID);

    public static final RegistryObject<Block> SHACK_CONSTRUCT =
            BLOCKS.register("shack_construct_block", ShackConstructBlock::new);
}
