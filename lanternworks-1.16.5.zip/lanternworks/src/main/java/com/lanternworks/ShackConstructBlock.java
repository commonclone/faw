package com.lanternworks;

import java.util.Random;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.material.MaterialColor;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

/** A glowing energy block that fades away after a few minutes. */
public class ShackConstructBlock extends Block {
    public static final int LIFETIME_TICKS = 6000;

    public ShackConstructBlock() {
        super(AbstractBlock.Properties.of(Material.GLASS, MaterialColor.EMERALD)
                .strength(0.8F)
                .noOcclusion()
                .lightLevel(state -> 8)
                .sound(SoundType.GLASS)
                .isViewBlocking((state, reader, pos) -> false)
                .isSuffocating((state, reader, pos) -> false));
    }

    @Override
    public void onPlace(BlockState state, World world, BlockPos pos, BlockState oldState, boolean moving) {
        if (!world.isClientSide) {
            world.getBlockTicks().scheduleTick(pos, this, LIFETIME_TICKS);
        }
    }

    @Override
    public void tick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        world.removeBlock(pos, false);
    }

    @Override
    public boolean skipRendering(BlockState state, BlockState adjacent, Direction side) {
        return adjacent.is(this) || super.skipRendering(state, adjacent, side);
    }
}
