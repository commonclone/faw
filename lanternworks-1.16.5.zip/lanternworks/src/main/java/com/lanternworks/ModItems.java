package com.lanternworks;

import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Rarity;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, LanternWorks.MOD_ID);

    public static final ItemGroup TAB = new ItemGroup("lanternworks") {
        @Override
        public ItemStack makeIcon() {
            return new ItemStack(BEAM_FOCUS.get());
        }
    };

    public static final RegistryObject<Item> BEAM_FOCUS = ITEMS.register("beam_focus",
            () -> new BeamFocusItem(new Item.Properties().tab(TAB).stacksTo(1).rarity(Rarity.RARE)));

    public static final RegistryObject<Item> SHACK_CONSTRUCT = ITEMS.register("shack_construct",
            () -> new ShackConstructItem(new Item.Properties().tab(TAB).stacksTo(1).rarity(Rarity.RARE)));

    public static final RegistryObject<Item> MECH_SUIT_CORE = ITEMS.register("mech_suit_core",
            () -> new MechSuitCoreItem(new Item.Properties().tab(TAB).stacksTo(1).rarity(Rarity.EPIC)));
}
