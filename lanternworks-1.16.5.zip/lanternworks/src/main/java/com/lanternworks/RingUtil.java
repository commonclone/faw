package com.lanternworks;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.util.ResourceLocation;

/** Talks to the Green Lantern power ring by registry id + its "Charge" NBT tag, so no compile link is needed. */
public final class RingUtil {
    private static final ResourceLocation RING_ID = new ResourceLocation("greenlantern", "power_ring");
    private static final String CHARGE_KEY = "Charge";
    private static final int START_CHARGE = 300;

    private RingUtil() {}

    private static boolean isRing(ItemStack stack) {
        return !stack.isEmpty() && RING_ID.equals(stack.getItem().getRegistryName());
    }

    public static ItemStack find(PlayerEntity player) {
        if (isRing(player.getMainHandItem())) return player.getMainHandItem();
        if (isRing(player.getOffhandItem())) return player.getOffhandItem();
        for (ItemStack stack : player.inventory.items) {
            if (isRing(stack)) return stack;
        }
        return ItemStack.EMPTY;
    }

    public static int charge(ItemStack ring) {
        CompoundNBT tag = ring.getTag();
        return tag != null && tag.contains(CHARGE_KEY) ? tag.getInt(CHARGE_KEY) : START_CHARGE;
    }

    /** Server side only. Returns true and drains the ring if it holds enough charge. */
    public static boolean spend(PlayerEntity player, int amount) {
        ItemStack ring = find(player);
        if (ring.isEmpty()) return false;
        int current = charge(ring);
        if (current < amount) return false;
        ring.getOrCreateTag().putInt(CHARGE_KEY, current - amount);
        return true;
    }
}
