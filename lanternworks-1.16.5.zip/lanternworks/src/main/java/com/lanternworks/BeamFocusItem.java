package com.lanternworks;

import java.util.Optional;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.util.ActionResult;
import net.minecraft.util.DamageSource;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.RayTraceContext;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

public class BeamFocusItem extends Item {
    public static final int COST = 40;
    public static final float DAMAGE = 10.0F;
    public static final double RANGE = 32.0D;

    public BeamFocusItem(Item.Properties props) {
        super(props);
    }

    @Override
    public ActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (world.isClientSide) {
            return ActionResult.success(held);
        }
        if (player.getCooldowns().isOnCooldown(this)) {
            return ActionResult.fail(held);
        }
        if (!RingUtil.spend(player, COST)) {
            player.displayClientMessage(new StringTextComponent("The beam needs a Power Ring with enough charge."), true);
            return ActionResult.fail(held);
        }

        Vector3d eye = player.getEyePosition(1.0F);
        Vector3d look = player.getLookAngle();
        Vector3d end = eye.add(look.scale(RANGE));

        BlockRayTraceResult blockHit = world.clip(new RayTraceContext(eye, end,
                RayTraceContext.BlockMode.COLLIDER, RayTraceContext.FluidMode.NONE, player));
        Vector3d stop = blockHit.getType() == RayTraceResult.Type.MISS ? end : blockHit.getLocation();

        AxisAlignedBB box = player.getBoundingBox().expandTowards(look.scale(RANGE)).inflate(1.0D);
        Entity target = null;
        double best = eye.distanceToSqr(stop);
        for (Entity e : world.getEntities(player, box, ent -> !ent.isSpectator() && ent.isPickable())) {
            AxisAlignedBB bb = e.getBoundingBox().inflate(e.getPickRadius() + 0.3D);
            Optional<Vector3d> hit = bb.clip(eye, stop);
            if (hit.isPresent()) {
                double d = eye.distanceToSqr(hit.get());
                if (d < best) {
                    best = d;
                    target = e;
                }
            }
        }

        Vector3d impact = stop;
        if (target != null) {
            target.hurt(DamageSource.playerAttack(player), DAMAGE);
            target.push(look.x * 0.6D, 0.2D, look.z * 0.6D);
            impact = eye.add(look.scale(Math.sqrt(best)));
        }

        ServerWorld sw = (ServerWorld) world;
        double length = eye.distanceTo(impact);
        Vector3d start = eye.add(look.scale(0.8D)).add(0.0D, -0.15D, 0.0D);
        int steps = (int) Math.min(80, length / 0.4D);
        for (int i = 0; i <= steps; i++) {
            Vector3d p = start.add(look.scale(i * 0.4D));
            sw.sendParticles(ParticleTypes.HAPPY_VILLAGER, p.x, p.y, p.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        }
        sw.sendParticles(ParticleTypes.HAPPY_VILLAGER, impact.x, impact.y, impact.z, 12, 0.3D, 0.3D, 0.3D, 0.05D);
        world.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.BEACON_ACTIVATE, SoundCategory.PLAYERS, 0.6F, 1.8F);

        player.getCooldowns().addCooldown(this, 10);
        return ActionResult.success(held);
    }
}
