package com.lanternworks;

import net.minecraft.entity.EntityClassification;
import net.minecraft.entity.EntityType;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITIES, LanternWorks.MOD_ID);

    public static final RegistryObject<EntityType<MechSuitEntity>> MECH_SUIT = ENTITIES.register("mech_suit",
            () -> EntityType.Builder.<MechSuitEntity>of(MechSuitEntity::new, EntityClassification.MISC)
                    .sized(1.6F, 3.1F)
                    .clientTrackingRange(10)
                    .build(LanternWorks.MOD_ID + ":mech_suit"));
}
