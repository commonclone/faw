package com.lanternworks;

import java.util.List;
import javax.annotation.Nullable;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.attributes.AttributeModifierMap;
import net.minecraft.entity.ai.attributes.Attributes;
import net.minecraft.entity.MobEntity;
import net.minecraft.entity.monster.IronGolemEntity;
import net.minecraft.entity.monster.MonsterEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.DamageSource;
import net.minecraft.util.Hand;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

/** A rideable energy mech. Built on the iron golem body so it reuses vanilla animation and model. */
public class MechSuitEntity extends IronGolemEntity {
    public static final int LIFETIME_TICKS = 6000;
    public static final float CRUSH_DAMAGE = 6.0F;

    private int life;

    public MechSuitEntity(EntityType<? extends IronGolemEntity> type, World world) {
        super(type, world);
        this.maxUpStep = 1.5F;
    }

    public static AttributeModifierMap.MutableAttribute createMechAttributes() {
        return MobEntity.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 120.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.ATTACK_DAMAGE, 15.0D);
    }

    @Override
    protected void registerGoals() {
        // No AI. The mech only moves when someone is riding it.
    }

    @Override
    public ActionResultType mobInteract(PlayerEntity player, Hand hand) {
        if (!this.level.isClientSide && !this.isVehicle()) {
            player.startRiding(this);
        }
        return ActionResultType.sidedSuccess(this.level.isClientSide);
    }

    @Override
    public double getPassengersRidingOffset() {
        return this.getBbHeight() * 0.8D;
    }

    @Nullable
    @Override
    public Entity getControllingPassenger() {
        List<Entity> passengers = this.getPassengers();
        return passengers.isEmpty() ? null : passengers.get(0);
    }

    @Override
    public void travel(Vector3d travelVector) {
        if (this.isAlive() && this.isVehicle() && this.getControllingPassenger() instanceof LivingEntity) {
            LivingEntity rider = (LivingEntity) this.getControllingPassenger();
            this.yRot = rider.yRot;
            this.yRotO = this.yRot;
            this.xRot = rider.xRot * 0.5F;
            this.setRot(this.yRot, this.xRot);
            this.yBodyRot = this.yRot;
            this.yHeadRot = this.yBodyRot;

            float strafe = rider.xxa * 0.5F;
            float forward = rider.zza;
            if (forward <= 0.0F) {
                forward *= 0.25F;
            }

            this.flyingSpeed = this.getSpeed() * 0.1F;
            if (this.isControlledByLocalInstance()) {
                this.setSpeed((float) this.getAttributeValue(Attributes.MOVEMENT_SPEED) * 1.6F);
                super.travel(new Vector3d(strafe, travelVector.y, forward));
            } else if (rider instanceof PlayerEntity) {
                this.setDeltaMovement(Vector3d.ZERO);
            }
            this.calculateEntityAnimation(this, false);
        } else {
            super.travel(travelVector);
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level.isClientSide) {
            return;
        }
        this.life++;
        Entity rider = this.getControllingPassenger();

        // Crush aura: hostile mobs next to a ridden mech take damage.
        if (rider instanceof PlayerEntity && this.tickCount % 10 == 0) {
            for (MonsterEntity monster : this.level.getEntitiesOfClass(MonsterEntity.class,
                    this.getBoundingBox().inflate(2.0D, 0.5D, 2.0D))) {
                monster.hurt(DamageSource.playerAttack((PlayerEntity) rider), CRUSH_DAMAGE);
            }
        }

        if (this.life >= LIFETIME_TICKS) {
            ((ServerWorld) this.level).sendParticles(ParticleTypes.HAPPY_VILLAGER,
                    this.getX(), this.getY() + 1.5D, this.getZ(), 40, 0.8D, 1.2D, 0.8D, 0.05D);
            this.remove();
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundNBT tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("MechLife", this.life);
    }

    @Override
    public void readAdditionalSaveData(CompoundNBT tag) {
        super.readAdditionalSaveData(tag);
        this.life = tag.getInt("MechLife");
    }
}
