package com.lanternworks;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUseContext;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.World;

public class MechSuitCoreItem extends Item {
    public static final int COST = 400;

    public MechSuitCoreItem(Item.Properties props) {
        super(props);
    }

    @Override
    public ActionResultType useOn(ItemUseContext ctx) {
        World world = ctx.getLevel();
        PlayerEntity player = ctx.getPlayer();
        if (world.isClientSide || player == null) {
            return ActionResultType.sidedSuccess(world.isClientSide);
        }
        if (player.getCooldowns().isOnCooldown(this)) {
            return ActionResultType.FAIL;
        }
        MechSuitEntity mech = ModEntities.MECH_SUIT.get().create(world);
        if (mech == null) {
            return ActionResultType.FAIL;
        }
        if (!RingUtil.spend(player, COST)) {
            player.displayClientMessage(new StringTextComponent("The mech needs a Power Ring with enough charge."), true);
            return ActionResultType.FAIL;
        }

        BlockPos pos = ctx.getClickedPos().relative(ctx.getClickedFace());
        mech.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, player.yRot, 0.0F);
        world.addFreshEntity(mech);
        player.startRiding(mech);
        world.playSound(null, pos, SoundEvents.BEACON_ACTIVATE, SoundCategory.PLAYERS, 1.0F, 0.6F);

        player.getCooldowns().addCooldown(this, 100);
        return ActionResultType.CONSUME;
    }
}
