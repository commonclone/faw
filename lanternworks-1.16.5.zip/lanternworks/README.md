# Lantern Works (Minecraft 1.16.5, Forge 36.2.39)

Companion mod for the Green Lantern mod (`greenlantern` 1.0.0+). Required at runtime.
Everything here spends charge from your Power Ring (max 1000).

| Item | Use | Ring cost |
|------|-----|-----------|
| Beam Focus | Right-click: instant green beam, 10 damage, 32 block range | 40 |
| Shack Construct | Right-click a block: builds a 5x5 glowing shack with a door facing you | 150 |
| Mech Suit Core | Right-click a block: summons a mech and mounts you. Sneak to dismount | 400 |

Shack blocks and the mech fade after 5 minutes. A ridden mech damages hostile mobs next to it.
Right-click an unridden mech to climb back in.
